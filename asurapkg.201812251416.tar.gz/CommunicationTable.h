/* CommunicationTable.c */
void InitializeCommunicationTable(void);
