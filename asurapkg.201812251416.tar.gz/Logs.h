/* Logs.c */
void InitLogFiles(void);
void CloseLogFiles(void);
void LogOutPutEnergyMomentumAngularMomentum(void);
void LogOutPutElapsedTime(void);
void EndLogs(void);
void LogsThisTimeStep(void);
void ClearTimingLogsThisStep(void);
void UpdateTimeLogs(void);
void LogTotalMass(void);
