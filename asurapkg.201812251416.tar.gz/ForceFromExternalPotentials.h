/* ForceFromExternalPotentials.c */
void ForceFromExternalPotentials(void);
