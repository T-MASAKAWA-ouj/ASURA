/* PlantStellarTree.c */
void InitializeRootForStellar(void);
void PlantStellarTree(void);
void PlantStellarTreePartial(void);
