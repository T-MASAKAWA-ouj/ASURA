/* BoundaryCondition.c */
void ImposeBoundaryCondition(const int mode);
