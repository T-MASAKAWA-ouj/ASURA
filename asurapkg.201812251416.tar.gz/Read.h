/* Read.c */
void ReadCosmologicalData(void);
void ReadOldCosmologicalData(const int FileID);
void ReadOldCosmologicalDataFull(const int FileID);
void ReadCosmologicalHalfwayData(char *fname);
