/* Exit.c */
void ASURA_Exit(void);
