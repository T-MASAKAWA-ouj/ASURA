/* ./ParticleAddRemoveOperation.c */
void ParticleRemoverArbitraryCriteria(bool (*criteria)(const int index));
