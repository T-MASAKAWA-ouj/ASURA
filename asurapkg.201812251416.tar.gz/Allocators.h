/* Allocation.c */
void *Allocate(size_t nSize);
void *ReAllocate(void *ptr, size_t nSize);
void Delete(void *p);
