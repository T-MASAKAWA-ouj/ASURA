/* ParallelOperation.c */
void UpdateTotalNumber(void);
void UpdateTotalActiveNumber(void);
void UpdateTotalStarNumber(void);
