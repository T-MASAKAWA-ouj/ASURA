/* HydroDensity.c */
void CalcDensityDivRot(void);
#if 0
void CalcKernelDensityDivRot(void);
#endif
void CalcDensityDivRotDirect(void);
