/* ./HIIregion.c */
void InitializeHIIregions(void);
void HIIregions(void);
int CheckHIIflags(const int step);
double ReturnRecombinationConstantAlpha(void);
double ReturnNumberofLyPhoton(const int index, const int step);
