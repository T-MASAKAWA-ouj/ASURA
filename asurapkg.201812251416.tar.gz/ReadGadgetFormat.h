/* ReadGadgetFormat.c */
int ReadGadetFormat(void);
