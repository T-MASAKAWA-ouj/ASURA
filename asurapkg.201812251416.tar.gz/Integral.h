/* Integral.c */
void Kick1Drift(void);
void BuildPredictors(void);
void Kick2(void);
void UpdateGravityKickFlag(void);
void SetInitialHydroVelh(void);
