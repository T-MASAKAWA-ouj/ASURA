/* ElapsedTime.c */
double GetElapsedTime(void);
double GetCPUTime(void);
double GetElapsedTime_(void);
