/* FOF.c */
void AllocateStructFOF(void);
void ReleaseStructFOF(void);
void SetFOFLinkingLength(const double LL);
void FOFHaloFinder(void);
void ListUpFOFCatalog(void);
void WriteFOFCatalog(void);
