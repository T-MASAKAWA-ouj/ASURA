/* PeriodicWrapping.c */
double PeriodicDistance(const double x1, const double x2, const int dim);
void PeriodicWrappingi(double Pos[restrict]);
void PeriodicWrappingi(double Pos[restrict]);
void PeriodicWrapping(void);
