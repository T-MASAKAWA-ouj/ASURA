/* RunLogs.c */
void WriteMakeflags(void);
