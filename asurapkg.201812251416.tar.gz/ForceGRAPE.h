/* ForceGRAPE.c */
void InitializeGRAPE(void);
void SetGRAPE(void);
void ForceGRAPE(void);
