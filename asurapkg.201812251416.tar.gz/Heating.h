/* Heating.c */
void InitializeFarUltraVioletField(void);
double FUV(const double Ti, const double Rho, const double G0, const double Metallicity);
double FUVatR(double R);
