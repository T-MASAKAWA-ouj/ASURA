/* PlantGravityTree.c */
void InitializeRootForGravity(void);
void PlantGravityTree(void);
void PlantGravityTreeOld(void);
