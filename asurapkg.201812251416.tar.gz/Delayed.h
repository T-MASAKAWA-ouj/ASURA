/* Delayed.c */
void InitializeDelayedSNII(void);
void DelayedSNe(void);
