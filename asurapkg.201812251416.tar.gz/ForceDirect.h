/* ForceDirect.c */
void ForceDirect(void);
void PotentialDirect(void);
#ifdef USE_SYMMETRIZED_SOFTENING
void CalcSymmetrizedPotential(void);
#endif // USE_SYMMETRIZED_SOFTENING
