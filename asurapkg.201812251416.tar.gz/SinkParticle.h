/* ./SinkParticle.c */
void SinkParticles(void);
void SinkHydroAccretionExported(void);
void SinkSinkMergingExported(void);
void SinkSinkMerging(void);
