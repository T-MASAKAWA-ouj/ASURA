/* GRAPEManager.c */
void HoldGRAPE(void);
void ReleaseGRAPE(void);
