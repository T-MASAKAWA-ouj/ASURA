/* SNII.c */
void InitializeSNII(void);
void ConstantSNII(const double SFRate);
