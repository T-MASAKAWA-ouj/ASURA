/* TimeStep.c */
void FirstTimeStep(void);
void BuildHierarchicalTimeStep(void);
void BuildNewTimeStep(void);
void RaiseActiveFlags(void);
