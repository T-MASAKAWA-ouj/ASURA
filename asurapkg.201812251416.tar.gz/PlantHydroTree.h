/* PlantHydroTree.c */
void InitializeRootForHydro(void);
void PlantHydroTree(void);
void PlantHydroTreeUpdate(void);
void PlantHydroTreeKernelMaxUpdate(void);
