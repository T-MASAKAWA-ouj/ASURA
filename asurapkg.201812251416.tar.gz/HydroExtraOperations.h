/* HydroExtraOperations.c */
void CalcExtraOperationsForHydro(void);
