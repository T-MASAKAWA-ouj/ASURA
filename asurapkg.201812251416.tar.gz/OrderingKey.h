/* OrderingKey.c */
void MakeOrderingKey(void);
