/* Decomposition.c */
void DomainDecompositionOnlyDataExchange(void);
void DomainDecomposition(void);
