/* PlantHydroTreeImported.c */
void InitializeRootForHydroImported(void);
void PlantHydroTreeImported(const int NumberofLeaves, struct StructHydroAccExport HydroAccExportRecv[restrict]);
