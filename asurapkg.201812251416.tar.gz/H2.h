double TemperatureDependentFH2(double Tg, double G0g);
double dn2(double n1, double n2, double Tk);
