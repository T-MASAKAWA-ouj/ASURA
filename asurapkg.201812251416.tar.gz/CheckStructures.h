/* ./CheckStructures.c */
void CheckHydroStructures(const int mode);
