/* PreDecomposition.c */
void InitializeDecomposition(void);
void PreDomainDecomposition(void);
void PreDomainDecompositionNew(const int mode);
void PreDomainDecomposition_(void);
void PreDomainDecompositionWeight(void);
void InspectParticleFluctuation(void);
