/* ForceMisc.c */
void ClearLocalAccPot(void);
void ClearGravitationalForce(void);
void ForceEndProcedure(void);
double ReturnInteractionListInDouble(void);
void PrintForceFlops(double Time);
