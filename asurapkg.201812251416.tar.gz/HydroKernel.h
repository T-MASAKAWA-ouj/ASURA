/* KernelUpdate.c */
void CalcKernel(void);
void CountNeighborNumber(void);
void CountDirectNeighborNumber(void);
void CalcKernelDensity(void);
